public class store
{
	public static void main(String[] Args)
	{
		/*
		<form action="http://localhost:8888/cgi-bin/service.cgi" method="GET">
		<input type="text" name="name">
		<input type="text" name="password">
		<input type="submit">
		</form>
		*/
		System.out.println("hrllo");
		System.out.println("<form action=\"http://localhost:8888/cgi-bin/service.cgi\" method=\"GET\">");
		System.out.println("<input type=\"text\" name=\"name\">");
		System.out.println("<input type=\"text\" name=\"password\">");
		System.out.println("<input type=\"submit\">");
		System.out.println("</form>");
	}
}
